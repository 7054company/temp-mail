let notificationMsgs = localStorage.getItem('notificationMsgs') ? JSON.parse(localStorage.getItem('notificationMsgs')) : [];
let mailboxMsgs = localStorage.getItem('mailboxMsgs') ? JSON.parse(localStorage.getItem('mailboxMsgs')) : [];

$(document).on('click', '.mail-item', function () {
    var id = $(this).attr('id');
    $(".tm-message > div").fadeOut(100);
    if($(this).hasClass('active')) {
        $(this).removeClass('active');
        $(".tm-message > .no-mails").delay(100).fadeIn(100);
    } else {
        $(".mail-item").removeClass('active');
        $(this).addClass('active');
        $(".tm-message > .no-mails").fadeOut(100);
        $("#content-"+id).delay(100).fadeIn(100);
    }
});

$(document).on('click', '.tm-domain-selector', function () {
    if($(this).hasClass('open')) {
        $(this).removeClass('open');
    } else {
        $(this).addClass('open');
    }
});

$(document).on('click', '.domain-selector', function () {
    var value = $(this).text();
    $("input[type='hidden'][name='domain']").val(value.replace('@', ''));
    $("#selected-domain").html(value);
});

$(document).on('click', '#btn-new', function () {
    $( "#actions-flip > .front" ).slideUp( 300, function() {
        $( "#actions-flip > .back" ).slideDown( 300 );
    });
});

$(document).on('click', '#btn-cancel', function () {
    $( "#actions-flip > .back" ).slideUp( 300, function() {
        $( "#actions-flip > .front" ).slideDown( 300 );
    });
});

$(document).on('click', '.action-item', function () {
    var action = $(this).attr('action');
    if(action == "delete") {
        $.post("/mailbox/delete", {
            "_token": $('#token').val()
        },
        function(data, status){
            if(data) {
                window.location.href = "/mailbox/"+data;
            } else {
                window.location.href = "/";
            }
        });
    } else if (action == "copy") {
        var input = document.getElementById("current-id");
        var isiOSDevice = navigator.userAgent.match(/ipad|iphone/i);
        if (isiOSDevice) {
            var editable = input.contentEditable;
            var readOnly = input.readOnly;
            input.contentEditable = true;
            input.readOnly = false;
            var range = document.createRange();
            range.selectNodeContents(input);
            var selection = window.getSelection();
            selection.removeAllRanges();
            selection.addRange(range);
            input.setSelectionRange(0, 999999);
            input.contentEditable = editable;
            input.readOnly = readOnly;
        } else {
            input.select();
        }
        document.execCommand('copy');
        input.blur();
    } else if (action == "refresh") {
        if($(".refresh > span.icon > i").hasClass("stop-spinner")) {
            return true;
        }
        if($(".refresh > span.icon > i").hasClass("pause-spinner")) {
            $(".refresh > span.icon > i").removeClass("pause-spinner");
            var currentRequest = null;  
            currentRequest = $.ajax({
                url: "/mail/fetch?new=true", 
                beforeSend : function()    {           
                    if(currentRequest != null) {
                        currentRequest.abort();
                    }
                },
                success: function(data){
                    if(data.length > 0) {
                        $("#mails > p").remove();
                    }
                    fetch(data, true);
                },
                error: function(data, status) {
                    Swal.fire({
                        type: status,
                        title: 'Oops...',
                        text: notificationMsgs.error.common,
                        confirmButtonText: notificationMsgs.button.reload,
                        footer: '<a href="/faq">'+notificationMsgs.faq+'</a>',
                        onClose: function(){ location.reload(); }
                    });
                    $("#mails").html("<p>ERROR</p>");
                    $(".refresh > span.icon > i").addClass("pause-spinner");
                    $(".refresh > span.icon > i").addClass("stop-spinner");
                }
            });
        }
    }
});

$(document).on('click', '.close-mail-content', function () {
    $(".mail-item").removeClass('active');
    $(".mail-content").fadeOut(100);
});

$(document).on('click', '.snackbar', function () {
    var msg = $(this).attr('msg');
    $("#snackbar").html(msg);
    $("#snackbar").addClass('show');
    setTimeout(function(){ 
        $("#snackbar").removeClass('show');
    }, 3000);
});

$(document).on('click', '#toggle', function () {
    $(this).toggleClass('active');
    $('#overlay').toggleClass('open');
});

function fetch(mails, newFetch = false) {
    $(".refresh > span.icon > i").addClass("pause-spinner");
    $.each( mails, function( key, value ) {
        if(key == "length") {
            return true;
        }
        $("#mails").prepend('<div id="mail-'+key+'" class="mail-item"><div class="row sender-time"><div class="col-6 sender">'+value['sender_name']+'</div><div class="col-6 time">'+value['short_time']+'</div></div><div class="subject">'+value['subject']+'</div><div class="message">'+value['text'].substring(0, 150)+'</div></div>');

        value['html'] = value['html'].replace("a href", "a target='_blank' href");

        var message = '<div id="content-mail-'+key+'" class="mail-content"><div class="close-mail-content"><i class="fas fa-angle-double-left"></i><span>View all mails</span></div><div class="subject">'+value['subject']+'</div><div class="row sender-time"><div class="col-md-9 sender">'+value['sender_name']+' - '+value['sender_email']+'</div><div class="col-md-3 time">'+value['time']+'</div></div><div class="mail-delete" uid="'+key+'"><i class="fas fa-trash-alt"></i></div><div class="message">'+value['html']+'</div><div class="attachments">';
        $.each( value['attachments'], function( akey, avalue ) {
            message += '<a href="'+avalue['path']+'" download="" target="_blank"><i class="fas fa-paperclip"></i>'+avalue['name']+'</a>';
        });
        message += '</div></div>';
        $(".tm-message").prepend(message);
        
        if(newFetch) {
            notifyUser(value['subject'], value['text'].substring(0, 50));
        }
    });
}

$(document).on('click', '#fetch', function () {
    $.ajax({
        url: "/mail/fetch", 
        success: function(data){
            if(data.length > 0) {
                $("#mails").html("");
                fetch(data);
            } else {
                $(".refresh > span.icon > i").addClass("pause-spinner");
                $("#mails").html("<p>"+mailboxMsgs.nomails+"</p>");
                setTimeout(function(){ 
                    $("#mails").html("<p>"+mailboxMsgs.emails+"</p>");
                }, 3000);
            }
        },
        error: function(data, status) {
            Swal.fire({
                type: status,
                title: 'Oops...',
                text: notificationMsgs.error.common,
                confirmButtonText: notificationMsgs.button.reload,
                footer: '<a href="/faq">'+notificationMsgs.faq+'</a>',
                onClose: function(){ location.reload(); }
            });
            $("#mails").html("<p>ERROR</p>");
            $(".refresh > span.icon > i").addClass("pause-spinner");
            $(".refresh > span.icon > i").addClass("stop-spinner");
        }
    });
    $("#fetch").remove();
});

$(document).on('click', '.mail-delete', function () {
    var uid = $(this).attr('uid');
    $("#mail-"+uid).fadeOut();
    $("#content-mail-"+uid).fadeOut();
    $(".tm-message > .no-mails").delay(100).fadeIn(100);
    $.post("/mail/delete", {
        "_token": $('#token').val(),
        "uid": uid
    },
    function(data, status){
        $("#mail-"+data).remove();
        $("#content-mail-"+data).remove();
        if($("#mails").is(":empty")) {
            $("#mails").html("<p>"+mailboxMsgs.emails+"</p>");
        }
    }).fail(function() {
        Swal.fire({
            type: "error",
            title: 'Oops...',
            text: notificationMsgs.error.delete,
            confirmButtonText: notificationMsgs.button.close,
            footer: '<a href="/faq">'+notificationMsgs.faq+'</a>'
        });
        $("#mail-"+uid).fadeIn();
        $("#content-mail-"+uid).fadeIn();
    });
});

$(document).on('change', '#locale', function () {
    var locale = $(this).val();
    $.post("/locale", {
        "_token": $('#token').val(),
        "locale": locale
    },
    function(data, status){
        location.reload();
    }).fail(function() {
        Swal.fire({
            type: "error",
            title: 'Oops...',
            text: notificationMsgs.error.common,
            confirmButtonText: notificationMsgs.button.reload,
            footer: '<a href="/faq">'+notificationMsgs.faq+'</a>'
        });
        $("#mail-"+uid).fadeIn();
        $("#content-mail-"+uid).fadeIn();
    });
});

function notifyUser(title = "", body = "") {
    var options = {
        body: body,
        icon: "/images/icon.png"
    };
    if(title) {
        if (Notification.permission === "granted") {
            var n = new Notification(title, options);
            n.onclick = function () {
                window.focus();
            };
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission(function(permission) {
                if (permission === "granted") {
                    var n = new Notification(title, options);
                    n.onclick = function () {
                        window.focus();
                    };
                }
            });
        }
    }
}
