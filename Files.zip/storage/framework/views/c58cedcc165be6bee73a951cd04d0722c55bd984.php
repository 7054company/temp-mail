<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3 tm-sidebar">
            <div id="actions-flip" class="tm-actions">
                <div class="front">
                    <div class="tm-mailid">
                        <div class="row current-id">
                            <div class="col-10">
                                <input type="text" value="<?php echo e(session('tm_current_mail')); ?>" id="current-id" spellcheck="false">
                            </div>
                            <div class="col-2"><i class="fas fa-chevron-down"></i></div>
                        </div>
                        <div class="row all-ids">
                            <div class="col-10">
                                <?php $__currentLoopData = session('tm_mails'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($item); ?>"><?php echo e($item); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="tm-nav">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="action-item copy snackbar" action="copy" msg="<?php echo e(__('app.snackbar.copy')); ?>">
                                    <span class="icon"><i class="far fa-copy"></i></span>
                                    <span class="text"><?php echo e(__('app.copy')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="action-item refresh" action="refresh">
                                    <span class="icon"><i class="fas fa-sync-alt fa-spin"></i></span>
                                    <span class="text"><?php echo e(__('app.refresh')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="action-item" id="btn-new">
                                    <span class="icon"><i class="fas fa-plus"></i></span>
                                    <span class="text"><?php echo e(__('app.new')); ?></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="action-item" action="delete">
                                    <span class="icon"><i class="fas fa-trash-alt"></i></span>
                                    <span class="text"><?php echo e(__('app.delete')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="back">
                    <div class="tm-create">
                        <form method="POST" action="<?php echo e(route('MailIDCreateCustom')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="email" placeholder="<?php echo e(__('app.enter')); ?>">
                            <input type="hidden" name="domain" value="<?php echo e($domains[0]); ?>">
                            <div class="tm-domain-selector">
                                <div class="row current-id">
                                    <div class="col-10" id="selected-domain"><?php echo e("@".$domains[0]); ?></div>
                                    <div class="col-2"><i class="fas fa-chevron-down"></i></div>
                                </div>
                                <div class="row all-ids">
                                    <div class="col-10">
                                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="domain-selector" href="#"><?php echo e("@".$domain); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <input type="submit" action="Create" value="<?php echo e(__('app.create')); ?>">
                        </form>
                        <span><?php echo e(__('app.or')); ?></span>
                        <form method="POST" action="<?php echo e(route('MailIDCreateRandom')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="submit" action="Random" value="<?php echo e(__('app.random')); ?>">
                        </form>
                        <div id="btn-cancel"><?php echo e(__('app.cancel')); ?></div>
                    </div>
                </div>
            </div>
            <div class="tm-ads">
                <?php echo e(env('TM_AD_SPACE_1')); ?>

            </div>
        </div>
        <div class="col-md-3 tm-mailbox">
            <div class="row search">
                <div class="col-1 icon">
                    <i class="fas fa-search"></i>
                </div>
                <div class="col-10 input">
                    <input type="text" name="search" placeholder="<?php echo e(__('app.search')); ?>">
                </div>
            </div>
            <div id="mails"><p><?php echo e(__('app.mailbox.loading')); ?></p></div>
        </div>
        <div class="col-md-6 tm-message">
            <?php echo e(env('TM_AD_SPACE_3')); ?>

            <span class="no-mails">
                <img src="<?php echo e(asset('images/mails.png')); ?>">
            </span>
        </div>
        <button id="fetch" class="d-none">F</button>
        <div id="fetch-seconds" class="d-none"><?php echo e(env('TM_FETCH_SECONDS', 15)); ?></div>
        <div id="notification-msgs" class="d-none"><?php echo e(json_encode(__('app.notification'))); ?></div>
        <div id="mailbox-msgs" class="d-none"><?php echo e(json_encode(__('app.mailbox'))); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('addonJS'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script>
$(window).on('load', function() {
    $("#fetch").click();
});
setInterval(function() {
    $(".refresh").click();
}, <?php echo e(intval(env('TM_FETCH_SECONDS', 10)) * 1000); ?>);
localStorage.setItem('notificationMsgs', $("#notification-msgs").html());
localStorage.setItem('mailboxMsgs', $("#mailbox-msgs").html());
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMail\resources\views/app.blade.php ENDPATH**/ ?>