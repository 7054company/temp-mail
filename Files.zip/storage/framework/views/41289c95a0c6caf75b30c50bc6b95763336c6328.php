<?php $__env->startSection('addonCSS'); ?>
<link href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addonJS'); ?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8" defer></script>
<script src="<?php echo e(asset('js/admin/menu.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row manage-menu">
    <div class="col-md-12">
        <div class="description_box_title">
            <h3>Manage Menu</h3>
        </div>
    </div>
    <div class="col-md-6">
        <ul id="menu-structure" class="menu-list">
             <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($item->status): ?>
                    <li id="<?php echo e(++$id); ?>" data-link="<?php echo e($item->link); ?>" data-name="<?php echo e($item->name); ?>" data-type="<?php echo e($item->type); ?>">
                        <?php echo e($item->name); ?>

                        <span data-id="<?php echo e($id); ?>" class="delete"><i class="far fa-trash-alt"></i></span>
                        <span data-id="<?php echo e($id); ?>" class="edit"><i class="far fa-edit"></i></span>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
     </div>
    <div class="col-md-6">
        <ul id="available-menu-items" class="menu-list"> 
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$item->status): ?>
                    <li id="<?php echo e(++$id); ?>" data-link="<?php echo e($item->link); ?>" data-name="<?php echo e($item->name); ?>" data-type="<?php echo e($item->type); ?>">
                        <?php echo e($item->name); ?>

                        <span data-id="<?php echo e($id); ?>" class="delete"><i class="far fa-trash-alt"></i></span>
                        <span data-id="<?php echo e($id); ?>" class="edit"><i class="far fa-edit"></i></span>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>     
    <div class="col-md-12">
        <div class="menu-updater menu-form">
            <form name="menu-updater" id="menu-updater">
                <input type="text" name="name" placeholder="Name">
                <input type="text" name="link" placeholder="Link">
                <label for="new_tab_update">
                    <input type="checkbox" id="new_tab_update" name="new_tab" value="true"/> <span>Open in New Tab</span>
                </label>
                <input type="hidden" name="id"><br>
                <div class="row">
                    <div class="col-md-6">
                        <button type="button" action="update" value="update">Update</button>
                    </div>
                    <div class="col-md-6">
                        <button type="button" action="cancel" value="cancel">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div> 
    <div class="col-md-12 hp-editor menu-form">
        <button type="button" id="save-menu-structure" class="blue-purple-bg">Save</button>
    </div>   
</div>
<div class="row add-new-menu-item menu-form">
    <div class="col-md-12">
        <div class="description_box_title">
            <h3>Add New Menu Item</h3>
        </div>
        <form name="menu-adder" id="menu-adder">
            <input type="text" name="name" placeholder="Name">
            <input type="text" name="link" placeholder="Link">
            <label for="new_tab_add">
                <input type="checkbox" id="new_tab_add" name="new_tab" value="true"/> <span>Open in New Tab</span>
            </label>
            <button type="button" value="add">Add</button>
        </form>
    </div>
</div>
    <div class="d-none" id="next-id"><?php echo e($id + 1); ?></div>
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\TMail\resources\views/admin/menu.blade.php */ ?>