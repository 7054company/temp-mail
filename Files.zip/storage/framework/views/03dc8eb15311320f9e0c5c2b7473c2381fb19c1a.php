<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'TMail')); ?></title>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(route('CustomCss')); ?>" media="all" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('addonCSS'); ?>
</head>
<body>
    <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 tm-logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
                    <div class="tm-mobile-menu-button" id="toggle">
                        <span class="top"></span><span class="middle"></span><span class="bottom"></span>
                    </div>
                </div>
                <div class="col-md-9 tm-menu">
                    <div class="row">
                        <div class="col-md-9">
                            <nav class="main">
                                <ul>
                                    <?php $__currentLoopData = App\Menu::where('status', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($menu->new_tab): ?> 
                                            <li><a href="<?php echo e($menu->link); ?>" target="_blank"><?php echo e($menu->name); ?></a></li>
                                        <?php else: ?> 
                                            <li><a href="<?php echo e($menu->link); ?>"><?php echo e($menu->name); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Auth::check()): ?>
                                    <li><a href="<?php echo e(env('APP_URL')); ?>/admin">Admin Panel</a></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-md-3">
                            <nav class="social">
                                <ul>
                                    <li><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a class="youtube" href="#"><i class="fab fa-youtube"></i></a></li>
                                    <li><a class="googleplus" href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                    <li>
                                        <select id="locale" name="locale">
                                            <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e((app()->getLocale() == $locale ) ? "selected" : ""); ?>><?php echo e($locale); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tm-mobile-menu" id="overlay">
            <nav class="overlay-menu">
                <ul>
                    <?php $__currentLoopData = App\Menu::where('status', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menu->new_tab): ?> 
                            <li><a href="<?php echo e($menu->link); ?>" target="_blank"><?php echo e($menu->name); ?></a></li>
                        <?php else: ?> 
                            <li><a href="<?php echo e($menu->link); ?>"><?php echo e($menu->name); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::check()): ?>
                    <li><a href="<?php echo e(env('APP_URL')); ?>/admin">Admin Panel</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
        <div id="snackbar"></div>
    </main>   
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('addonJS'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html>
<?php /* C:\xampp\htdocs\TMail\resources\views/layout.blade.php */ ?>