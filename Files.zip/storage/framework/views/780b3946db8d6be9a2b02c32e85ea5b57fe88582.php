<?php $__env->startSection('addonCSS'); ?>
<link href="<?php echo e(asset('css/admin.css?v='.env('APP_VERSION'))); ?>" rel="stylesheet">
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addonJS'); ?>
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script>
    var quill = new Quill('#editor', {
        theme: 'snow'
    });
</script>
<script>
    document.getElementById("btnSubmit").addEventListener("click", function(){
        var changedContent = quill.root.innerHTML;
        document.getElementById("content").innerHTML = changedContent;
        document.getElementById("pageForm").submit();
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-md-12">
                <h3 class="page_title">Pages</h3>
                <table class="table">
                    <thead>
                        <th>#</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Actions</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($page->id); ?></td>
                            <td><?php echo e($page->title); ?></td>
                            <td><?php echo e($page->slug); ?></td>
                            <td>
                                <a class="page-action" href="<?php echo e(route('AdminPageEdit')); ?>?id=<?php echo e($page->id); ?>">Edit</a>
                                <a class="page-action" href="<?php echo e(route('AdminPageDelete')); ?>?id=<?php echo e($page->id); ?>" onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row hp-editor">
            <div class="col-md-12">
                <h3 class="page_title">Add New Page</h3>
                <form method="POST" id="pageForm" action="<?php echo e(route('AdminPageAdd')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="page_title">
                        <label for="title">Page Title</label>
                        <input id="title" type="text" name="title" placeholder="Page Title" required>
                    </div>
                    <div class="page_slug">
                        <label for="title">Page Slug (ex. home, about)</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                              <span class="input-group-text" id="basic-addon1"><?php echo e(env('APP_URL')); ?>/</span>
                            </div>
                            <input id="slug" type="text" name="slug" value="" placeholder="Page Slug" required>
                        </div>
                    </div>
                    <div class="page_content">
                        <label for="content">Page Content</label>
                        <div id="editor"></div>
                    </div>
                    <textarea id="content" name="content"></textarea>
                    <button class="blue-bg" type="button" id="btnSubmit">Submit</button>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\TMail\resources\views/admin/pages.blade.php */ ?>