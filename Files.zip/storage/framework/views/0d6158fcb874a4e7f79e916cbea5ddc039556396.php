<?php $__env->startSection('page_title'); ?>
Welcome
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="offset-md-3 col-md-6">
            <h4 class="blue-text">TMail Installer</h4>
            <p>This installer will guide you through various installation process and will need you to create Database & Email account from your control panel. It will ask for various details which you will get from your control panel after creating Database and email account. Incase if you are not familiar on how to proceed watch the tutorial video here https://you.be/1Bs23 </p>
            <a href="<?php echo e(route('InstallLicense')); ?>"><button type="button" class="primary-btn blue-bg">Proceed</button></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('installer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMail\resources\views/installer/install.blade.php ENDPATH**/ ?>