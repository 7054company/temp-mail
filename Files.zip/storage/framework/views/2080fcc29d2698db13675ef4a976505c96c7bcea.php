<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'TMail')); ?></title>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(route('CustomCss')); ?>" media="all" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('addonCSS'); ?>
</head>
<body>
    <header>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 tm-logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
                    <div class="tm-mobile-menu-button" id="toggle">
                        <span class="top"></span><span class="middle"></span><span class="bottom"></span>
                    </div>
                </div>
                <div class="col-md-9 tm-menu">
                    <div class="row">
                        <div class="col-md-9">
                            <nav class="main">
                                <ul>
                                    <li><a <?php echo e(Request::is('admin/configuration') ? "class=active" : "class=a"); ?> href="<?php echo e(env('APP_URL')); ?>/admin/configuration">Configuration</a></li>
                                    <li><a <?php echo e(Request::is('admin/pages') ? "class=active" : "class=a"); ?> href="<?php echo e(env('APP_URL')); ?>/admin/pages">Pages</a></li>
                                    <li><a <?php echo e(Request::is('admin/menu') ? "class=active" : "class=a"); ?> href="<?php echo e(env('APP_URL')); ?>/admin/menu">Menu</a></li>
                                    <li><a <?php echo e(Request::is('admin/update') ? "class=active" : "class=a"); ?> href="<?php echo e(env('APP_URL')); ?>/admin/update">Update</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="col-md-3">
                            <nav class="social">
                                <ul>
                                    <li><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a class="youtube" href="#"><i class="fab fa-youtube"></i></a></li>
                                    <li><a class="googleplus" href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                    <li>
                                        <select id="locale" name="locale">
                                            <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e((app()->getLocale() == $locale ) ? "selected" : ""); ?>><?php echo e($locale); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tm-mobile-menu" id="overlay">
            <nav class="overlay-menu">
                <ul>
                    <li><a class="active" href="<?php echo e(env('APP_URL')); ?>/admin/configuration">Configuration</a></li>
                    <li><a href="<?php echo e(env('APP_URL')); ?>/admin/pages">Pages</a></li>
                    <li><a href="<?php echo e(env('APP_URL')); ?>/admin/menu">Menu</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 tm-sidebar">
                    <div class="tm-stats">
                        <div class="stats-item">
                            <span class="value"><?php echo e(number_format(env('STATS_EMAIL'), 0, '.', ',')); ?></span>
                            <span class="title">Email IDs Generated </span>
                        </div>
                        <div class="stats-item">
                            <span class="value"><?php echo e(number_format(env('STATS_RECEIVED'), 0, '.', ',')); ?></span>
                            <span class="title">Emails Received</span>
                        </div>
                    </div>
                    <div class="tm-ads">
                        <?php echo e(env('TM_AD_SPACE_1')); ?>

                    </div>
                </div>
                <div class="col-md-9 tm-content">
                    <?php if(isset($success)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e($success); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?> 
                    <?php if(!$errors->isEmpty()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Oops!</strong> We encountered some errors<br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($error); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
        <div id="snackbar"></div>
    </main>   
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('addonJS'); ?>
    <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\TMail\resources\views/admin/layout.blade.php ENDPATH**/ ?>