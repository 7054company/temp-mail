<?php $__env->startSection('addonCSS'); ?>
<link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
<style>
.addIcons {
    font-size: 36px;
    cursor: pointer;
}
.domains {
    margin-top: 5px;
}
.domains input {
    width: 100%;
    margin-top: 5px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addonJS'); ?>
<script>
$("#addDomain").click(function(){
    $("#addDomain").before('<div class="domains"><input type="text" name="domain[]" placeholder="Enter Domain"></div>');
});
$("#addAPI").click(function(){
    $("#addAPI").before('<div class="domains"><input type="text" name="api[]" placeholder="Enter API Key"></div>');
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3 class="page_title"><?php echo e($page_title); ?></h3>

<form method="POST" action="<?php echo e(route('AdminConfigurationSubmit')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="logo" class="col-form-label">Logo</label>
        <div class="field">
            <input type="file" id="logo" class="<?php echo e($errors->has("logo") ? ' is-invalid' : ''); ?>" name="logo">
            <?php if($errors->has("logo")): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first("logo")); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php $__currentLoopData = $env; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == "APP_FORCE_HTTPS"): ?>
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label">Force SSL?</label>
        <div class="field">
            <select id="<?php echo e($key); ?>" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>">
                <option value="true" <?php echo e($value ? 'selected' : ''); ?>>Yes</option>
                <option value="false" <?php echo e($value ? '' : 'selected'); ?>>No</option>
            </select>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif($key == "TM_DOMAINS"): ?>
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label">Domains</label>
        <div class="field">
            <?php $__currentLoopData = explode(',', $value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="domains">
                <input id="domain" type="text" name="domain[]" placeholder="Enter Domain" value="<?php echo e($domain); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="addIcons" id="addDomain">+</div>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif($key == "API_KEY"): ?>
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label">API Key(s)</label>
        <div class="field">
            <?php $__currentLoopData = explode(',', $value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="domains">
                <input id="api" type="text" name="api[]" placeholder="Enter API Key" value="<?php echo e($api); ?>">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="addIcons" id="addAPI">+</div>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif($key == "IMAP_VALIDATE_CERT"): ?>
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label">Enable SSL Check (IMAP)?</label>
        <div class="field">
            <select id="<?php echo e($key); ?>" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>">
                <option value="true" <?php echo e($value ? 'selected' : ''); ?>>Yes</option>
                <option value="false" <?php echo e($value ? '' : 'selected'); ?>>No</option>
            </select>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif(\strpos($key, 'TM_AD_SPACE_') !== false): ?> 
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label"><?php echo e(ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key))))); ?></label>
        <div class="field">
            <textarea id="<?php echo e($key); ?>" type="text" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>"><?php echo e($value); ?></textarea>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif(\strpos($key, 'TM_COLOR_') !== false): ?> 
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label"><?php echo e(ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key))))); ?></label>
        <div class="field">
            <input id="<?php echo e($key); ?>" type="color" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php elseif($key == "TM_HOMEPAGE"): ?> 
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label">Select Home Page</label>
        <div class="field">
            <select id="<?php echo e($key); ?>" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>">
                <option value="app" <?php echo e(($value == 'app') ? 'selected' : ''); ?>>App (Auto Generate ID)</option>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($page->slug); ?>" <?php echo e(($value == $page->slug) ? 'selected' : ''); ?>><?php echo e($page->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php else: ?>  
    <div class="form-group">
        <label for="<?php echo e($key); ?>" class="col-form-label"><?php echo e(ucwords(strtolower(str_replace("_"," ",str_replace("TM_"," ",$key))))); ?></label>
        <div class="field">
            <input id="<?php echo e($key); ?>" type="text" class="form-control<?php echo e($errors->has($key) ? ' is-invalid' : ''); ?>" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
            <?php if($errors->has($key)): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first($key)); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row mb-0">
        <div class="col-md-12 hp-editor menu-form">
            <button class="blue-bg" type="submit">Save</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TMail\resources\views/admin/configuration.blade.php ENDPATH**/ ?>